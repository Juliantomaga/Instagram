<?php 
$koneksi = mysqli_connect("localhost","root","123456","db_insta");
// if($koneksi) {
//  echo "berhasil";
// } else {
//  echo "gagal";
// }
?>
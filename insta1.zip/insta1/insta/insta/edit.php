<?php 
include "koneksi.php";
$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no'";
$query = mysqli_query($koneksi,$sql);
while($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=\, initial-scale=1.0">
 <link rel="stylesheet" href="css/bootstrap.min (3).css">
 <title>Document</title>
</head>
<body>
 <div class="container">
  <h1 class="text-center mt-3">Form Edit</h1>
 <form action="proses_edit.php" method="post" enctype="multipart/form-data" class="mt-4">
  <input type="hidden" name="no" value="<?=$post['no']?>" >
  <input type="hidden" name="foto_lama" value="<?=$post['foto']?>">
  <label for="" class="form-label">Foto</label>
  <input type="file" name="foto" id="" class="form-control" value="<?=$post['no']?>"> <br>
  <img src="images/<?=$post['foto']?>" alt="" width="100" height="100"><br><br>

  <label for="" class="form-label">Caption</label>
  <input type="text" name="caption" id="" class="form-control" value="<?=$post['caption']?>"> <br>
  <label for="" class="form-label">Lokasi</label>
  <input type="text" name="lokasi" id="" class="form-control" value="<?=$post['lokasi']?>"> <br>
  
  <input type="submit" value="simpan" name="ubah" class="btn btn-success">
  </div>
 </form>
</body>
</html>
<?php } ?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=\, initial-scale=1.0">
 <link rel="stylesheet" href="css/bootstrap.min (3).css">
 <title>Document</title>
</head>
<body>
 <div class="container">
  <h1 class="text-center mt-3">Form Tambah</h1>
 <form action="proses_tambah.php" method="post" enctype="multipart/form-data" class="mt-4">
  <label for="" class="form-label">Foto</label>
  <input type="file" name="foto" id="" class="form-control"> <br>
  <label for="" class="form-label">Caption</label>
  <input type="text" name="caption" id="" class="form-control"> <br>
  <label for="" class="form-label">Lokasi</label>
  <input type="text" name="lokasi" id="" class="form-control"> <br>
  
  <input type="submit" value="simpan" name="simpan" class="btn btn-success">
  </div>
 </form>
</body>
</html>
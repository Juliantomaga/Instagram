<?php 


function query($query){
    global $koneksi;
    $result = mysqli_query($koneksi,$query);
    $rows = [];
    while($rows = mysqli_fetch_assoc($result)) {
        $rows[] = $rows; 
    }
    return $rows;
}


function post() {
 $status = 1;

 $nama_file = $_FILES['foto'] ['name'];
 $tmp_name = $_FILES['foto'] ['tmp_name'];

 $error = $_FILES['foto']['error'];
 if($error === 4) {
  $pesan = 'tidak ada gambar yang di post';
  $status = 0;
 }

 $ukuran_file = $_FILES['foto']['size'];
 if($ukuran_file > 2000000) {
  $pesan = 'ukuran gambar terlalu besar';
  $status = 0;
 }

 $ekstensi_valid = ["jpg","jpeg","png"];
 $ekstensi_gambar = explode('.', $nama_file);
 $ekstensi_gambar = strtolower(end($ekstensi_gambar));

 if(!in_array($ekstensi_gambar, $ekstensi_valid)) {
  $pesan = 'format gambar tidak benar';
  $status = 0;
 }

 if($status == 0) {
  echo "<script>alert('terjadi kesalahan : " . $pesan . " '); 
  document.location.href='index.php';</script>";
  exit();
 } else {
  $nama_file_baru = uniqid();
  $nama_file_baru .= '.';
  $nama_file_baru .= $ekstensi_gambar;
  move_uploaded_file($tmp_name, 'images/' . $nama_file_baru);
  return $nama_file_baru;
 }
}

?>
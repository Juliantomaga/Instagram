<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
      <!-- style css -->
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <!-- fonts -->
      <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
      <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,500;0,700;1,700&family=Lato:wght@300;400&family=Poppins:ital,wght@0,400;0,500;0,700;0,900;1,100&family=Volkhov:ital@1&display=swap" rel="stylesheet">
      <!-- font awesome -->
      <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <!--  -->
      <!-- owl stylesheets -->
      <link href="https://fonts.googleapis.com/css?family=Great+Vibes|Poppins:400,700&display=swap&subset=latin-ext" rel="stylesheet">
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <link rel="stylesoeet" href="css/owl.theme.default.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- javascript -->
    <title>Document</title>
</head>
<body id="page-top">
    


<div id="wrapper">

  <!-- Sidebar -->
  
  
  <ul class="sidebar navbar-nav ">      
    <li class="nav-item active">
      <a class="nav-link" href="index.php">
        <i class="fa fa-fw fa-tachometer"></i>
        <span>Dashboard</span>
      </a>
    </li>
    <!-- Drop down item nonaktifkan
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-fw fa-folder"></i>
        <span>Berita</span>
      </a>
      <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <h6 class="dropdown-header">Berita :</h6>
        <a class="dropdown-item" href="tambah-berita.php">Tambah Berita</a>
        <a class="dropdown-item" href="lihat-berita.php">Postingan</a>
        <div class="dropdown-divider"></div>
        <h6 class="dropdown-header">Kategori Berita :</h6>
        <a class="dropdown-item" href="kategori-berita.php">Kategori</a>
        <a class="dropdown-item" href="lihat-kategori.php">Lihat</a>
      </div>
    </li>
  -->
    <li class="nav-item">
      <a class="nav-link" href="postingan.php">
        <i class="fa fa-fw fa-edit"></i>
        <span>Post</span></a>
    </li>
    
    <li class="nav-item">
      <a class="nav-link" href="postingan.php">
        <i class="fa fa-fw fa-edit"></i>
        <span>Post</span></a>
    </li>
  <!--  <li class="nav-item">
        <a class="nav-link" href="kategori-berita.php">
        <i class="fas fa-fw fa-book"></i>
        <span>Label</span></a>
        </li> 
  -->
  
 <!--   <li class="nav-item dropdown">
         <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-comments"></i>
          <span>Komentar</span>
        </a>
  -->    
  <!--      <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <h6 class="dropdown-header">Komentar :</h6>
        <a class="dropdown-item" href="#">Diterbitkan</a>
        <a class="dropdown-item" href="#">Menunggu Moderasi</a>
        <a class="dropdown-item" href="#">Spam</a>
       
    </li>
  -->   
      <li class="nav-item" >
      <a class="nav-link" href="pengguna.php">
        <i class="fa fa-fw fa-user-circle"></i>
        <span>User</span>
      </a>
     <!-- <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <h6 class="dropdown-header">Pengguna :</h6>
        <a class="dropdown-item" href="tambah-user.php">Tambah user</a>
        <a class="dropdown-item" href="profile-user.php">Profile</a>
             
    </li>
      <li class="nav-item">
      <a class="nav-link" href="subcribeme.php">
        <i class="fas fa-fw fa-user-circle"></i>
        <span>Subcribe</span></a>
    </li>
-->       
    <li class="nav-item">
      <a class="nav-link" href="/" target="_blank">
        <i class="fa fa-fw fa-globe"></i>
        <span>See Web</span>
      </a>
    </li>
    </ul>
</body>
</html>

    



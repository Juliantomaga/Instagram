<?php 
session_start();
if(!isset($_SESSION['login'])) {
 header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
require "functions.php";

$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi,$sql);




?>

<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="css/style.css">
 <link rel="icon" type="image/x-icon" href="foto/favicon.png">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
 <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="css/bootstrap.min (3).css">
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 <title>PicSocial</title>
<style>

.zoom-effect {  
  position: relative;
  width: 100%;
  height: 360px;
  margin: 0 auto;
  overflow: hidden;  
}
 
.kotak {
  position: absolute;
  top: 0;
  left: 0;
  
}
 
.kotak img {
  -webkit-transition: 0.4s ease;
  transition: 0.4s ease;
  width: 700px;
}
 
.zoom-effect:hover .kotak img {
  -webkit-transform: scale(1.08);
  transform: scale(1.08);
}

.navbar-brand{
  font-family: 'Bebas Neue', sans-serif;
}

</style>
</head>

<body>
<nav id="sidebarMenu" class="collapse d-lg-block sidebar collapse bg-white">
    <div class="position-sticky">
      <div class="list-group list-group-flush mx-3 mt-4" >
        <a
          href="#"
          class="list-group-item list-group-item-action py-2 ripple"
          aria-current="true" style="margin-top: 20px; ">

          <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal"  class="list-group-item list-group-item-action py-2 ripple ">
          <i class="bi bi-plus fa-fw me-3"><span></i>Tambah Postingan</span>
        </a>
        <a href="logout.php" class="list-group-item list-group-item-action py-2 ripple ">
          <i class="bi bi-box-arrow-right fa-fw me-3"></i><span>Logout</span>
        </a>
       
      </div>
    </div>
  </nav>
  <!-- Sidebar -->

  <!-- Navbar -->
  <nav id="main-navbar" class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
    <!-- Container wrapper -->
    <div class="container-fluid">
      <!-- Toggle button -->
      <button
        class="navbar-toggler"
        type="button"
        data-mdb-toggle="collapse"
        data-mdb-target="#sidebarMenu"
        aria-controls="sidebarMenu"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <i class="bi bi-bars"></i>
      </button>

      <!-- Brand -->
      <a class="navbar-brand" href="#">
        <img
          src="foto/logo_baru.png"
          height="90"
          alt="MDB Logo"
          loading="lazy" style="margin-right: 10px;"
        />
      </a>
      <!-- Search form -->
      <form class="d-none d-md-flex input-group w-auto" action="" method="post">
        <input
          autocomplete="off"
          type="text"
          class="form-control rounded"
          placeholder='Search'
          name="keyword"
          style="min-width: 225px;"
        />
        <button type="submit" name="cari" class="input-group-text border-0 ms-2"><i class="bi bi-search"></i></button>
      </form>

    </div>
    <!-- Container wrapper -->
  </nav>
  <!-- Navbar -->
</header>
<!--Main Navigation-->

<!--Main layout-->
<main style="margin-top: 58px;">
  <div class="container pt-4"></div>
</main>
<!--Main layout-->
<!-- 
<nav class="navbar navbar-expand-lg  sticky-top" >
  <div class="container-fluid ">
    <a class="navbar-brand" href="#" style="font-size: 30px;">Picsocial</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor04" aria-controls="navbarColor04" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
      <form class="d-flex" action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <a href="logout.php" class="btn btn-danger me-2" onclick="return confirm('Apakah Anda yakin ingin Logout?')" >Logout</a>
        <a href="tambah.php" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@getbootstrap"><i class="bi bi-plus-lg"></i></a>

      </form>
    </div>
  </div>
</nav> -->
 
<form action="proses_tambah.php" method="post" enctype="multipart/form-data">
<div class="modal fade " id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 " id="exampleModalLabel">Tambah Post</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Foto</label>
            <input type="file" class="form-control" id="recipient-name" name="foto">
          </div>
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Lokasi</label>
            <input type="text" class="form-control" id="recipient-name" name="lokasi">
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Caption</label>
            <textarea class="form-control" id="message-text" name="caption"></textarea>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
      </div>
    </div>
  </div>
</div>
</form>
<section id="gallery" >
<?php while ($post = mysqli_fetch_assoc($query)) { ?>
  <div class="container" >
    <div class="row  justify-content-center">
    <div class="col-md-6 mb-4">
    <div class="card" >
    <div class="zoom-effect">
			<div class="kotak">
      <img src="images/<?= $post['foto'] ?>" alt="" class="card-img-top">
      </div>
     </div>
      <div class="card-body">
        <h5 class="card-title"><?= $post['lokasi'] ?></h5>
        <p class="card-text"><?= $post['caption'] ?></p>
        <center>
       <a href="" type="button" class="btn btn-outline-success btn-lg" data-bs-toggle="modal" data-bs-target="#editmodal<?php echo $post['no']; ?>" data-bs-whatever="@getbootstrap"><i class="bi bi-pencil" style="font-size:18px;"></i></a>
       <a href="hapus.php?no=<?=$post['no']?>" class="btn btn-outline-danger btn-lg ms-2" onclick="return confirm('Apakah Anda yakin ingin menghapus?')"><i class="bi bi-trash" style="font-size:18px;" ></i></a>
       </center>
      </div>
    </div>
  </div>
</div>
</div>
<form class="d-flex" action="proses_edit.php" method="post" enctype="multipart/form-data">

       <div class="modal fade " id="editmodal<?php echo $post['no']; ?>" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 " id="exampleModalLabel">Edit Post</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="no" value="<?=$post['no']?>">
        <input type="hidden" name="foto_lama" value="<?=$post['foto']?>">
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Foto</label>
            <input type="file" class="form-control" id="recipient-name" name="foto" value="<?=$post['foto']?>"> 
          </div>
          <div class="mb-3">
           <img src="images/<?=$post['foto']?>" width="100" alt="">
          </div>
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Lokasi</label>
            <input type="text" class="form-control" id="recipient-name" name="lokasi" value="<?=$post['lokasi']?>">
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Caption</label>
            <input type="text" class="form-control" id="message-text" name="caption" value="<?=$post['caption']?>"></input>
          </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name="ubah">Simpan</button>
      </div>
     
    </div>
  </form>
  </div>
</div>

      </div>
    
    
      <?php } ?>

 </div>
 
</body>
</html>